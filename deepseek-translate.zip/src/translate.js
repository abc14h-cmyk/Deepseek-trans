load("language_list.js");
load("apikey.js");
load("prompt.js");

// ==================== CẤU HÌNH DEEPSEEK ====================
var DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions";
var DEEPSEEK_MODEL = "deepseek-chat"; // hoặc "deepseek-reasoner"
var DEEPSEEK_MAX_TOKENS = 8192;
var DEEPSEEK_TEMPERATURE = 1.0;

// ==================== CACHE ====================
function generateFingerprintCacheKey(lines) {
    var keyParts = "";
    var linesForId = lines.slice(0, 5);
    for (var i = 0; i < linesForId.length; i++) {
        var line = linesForId[i].trim();
        if (line.length >= 6) {
            keyParts += line.substring(0, 3) + line.slice(-3);
        } else {
            keyParts += line;
        }
    }
    return "vbook_ds_cache_" + keyParts;
}

function manageCacheAndSave(cacheKey, contentToSave) {
    var MAX_CACHE_SIZE = 50;
    var CACHE_MANIFEST_KEY = "vbook_ds_cache_manifest";
    try {
        var manifest = [];
        var rawManifest = localStorage.getItem(CACHE_MANIFEST_KEY);
        if (rawManifest) manifest = JSON.parse(rawManifest);

        while (manifest.length >= MAX_CACHE_SIZE) {
            manifest.sort(function(a, b) { return a.ts - b.ts; });
            var oldest = manifest.shift();
            if (oldest) localStorage.removeItem(oldest.key);
        }

        manifest.push({ key: cacheKey, ts: Date.now() });
        localStorage.setItem(CACHE_MANIFEST_KEY, JSON.stringify(manifest));
        localStorage.setItem(cacheKey, contentToSave);
    } catch (e) {
        try { localStorage.setItem(cacheKey, contentToSave); } catch (e2) {}
    }
}

// ==================== GỌI DEEPSEEK API ====================
function callDeepSeekAPI(text, prompt, apiKey) {
    if (!apiKey) return { status: "error", message: "API Key không hợp lệ." };
    if (!text || text.trim() === "") return { status: "success", data: "" };

    var body = {
        "model": DEEPSEEK_MODEL,
        "max_tokens": DEEPSEEK_MAX_TOKENS,
        "temperature": DEEPSEEK_TEMPERATURE,
        "messages": [
            { "role": "system", "content": prompt },
            { "role": "user", "content": text }
        ]
    };

    try {
        var response = fetch(DEEPSEEK_API_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apiKey
            },
            body: JSON.stringify(body)
        });

        var responseText = response.text();

        if (response.ok) {
            var result = JSON.parse(responseText);
            if (result.choices && result.choices.length > 0 &&
                result.choices[0].message && result.choices[0].message.content) {
                return { status: "success", data: result.choices[0].message.content.trim() };
            }
            if (result.error) {
                return { status: "error", message: "API Error: " + (result.error.message || JSON.stringify(result.error)) };
            }
            return { status: "error", message: "API không trả về nội dung hợp lệ. Phản hồi: " + responseText };
        } else {
            var errorMsg = "Lỗi HTTP " + response.status;
            try {
                var errResult = JSON.parse(responseText);
                if (errResult.error && errResult.error.message) {
                    errorMsg += ": " + errResult.error.message;
                } else {
                    errorMsg += ". Phản hồi: " + responseText;
                }
            } catch (e) {
                errorMsg += ". Phản hồi: " + responseText;
            }
            return { status: "key_error", message: errorMsg };
        }
    } catch (e) {
        return { status: "error", message: "Ngoại lệ Javascript: " + e.toString() };
    }
}

// ==================== THỬ LẦN LƯỢT CÁC KEY ====================
function translateChunkWithRetry(chunkText, prompt, keysToTry) {
    var keyErrors = [];
    for (var i = 0; i < keysToTry.length; i++) {
        var result = callDeepSeekAPI(chunkText, prompt, keysToTry[i]);

        if (result.status === "success") {
            if (result.data.length > 0 && (result.data.length / chunkText.length) < 0.5) {
                result.status = "short_result_error";
                result.message = "Kết quả trả về quá ngắn so với văn bản gốc.";
            } else {
                return result;
            }
        }

        keyErrors.push("  + Key " + (i + 1) + " (" + keysToTry[i].substring(0, 6) + "...): " + result.message);

        if (i < keysToTry.length - 1) {
            try { sleep(200); } catch (e) {}
        }
    }
    return {
        status: "all_keys_failed",
        message: "Tất cả API keys đều thất bại.",
        details: keyErrors
    };
}

// ==================== HÀM CHÍNH ====================
function execute(text, from, to) {
    if (!text || text.trim() === "") {
        return Response.success("?");
    }

    // Xoá cache
    if (to === "vi_xoacache") {
        var lines0 = text.split("\n");
        if (text.length >= 800) {
            var cacheKeyDel = generateFingerprintCacheKey(lines0);
            if (localStorage.getItem(cacheKeyDel) !== null) {
                localStorage.removeItem(cacheKeyDel);
                return Response.success("Đã xóa cache thành công.\n" + text);
            }
        }
        return Response.success(text);
    }

    // Xoay vòng API key
    var rotatedKeys = apiKeys;
    try {
        if (apiKeys && apiKeys.length > 1) {
            var lastIdx = parseInt(localStorage.getItem("vbook_ds_last_key_idx") || "-1");
            var nextIdx = (lastIdx + 1) % apiKeys.length;
            rotatedKeys = apiKeys.slice(nextIdx).concat(apiKeys.slice(0, nextIdx));
            localStorage.setItem("vbook_ds_last_key_idx", nextIdx.toString());
        }
    } catch (e) {
        rotatedKeys = apiKeys;
    }

    if (!rotatedKeys || rotatedKeys.length === 0) {
        return Response.error("LỖI: Vui lòng thêm ít nhất 1 DeepSeek API key vào file apikey.js");
    }

    var lines = text.split("\n");

    // Phân loại văn bản ngắn / danh sách
    var isShortOrList = false;
    var lengthThreshold = to === "vi_vietlai" ? 1500 : 1000;
    var lineLenThreshold = to === "vi_vietlai" ? 50 : 25;

    if (text.length < lengthThreshold) {
        isShortOrList = true;
    } else {
        var shortCount = 0;
        for (var i = 0; i < lines.length; i++) {
            if (lines[i].length < lineLenThreshold) shortCount++;
        }
        if (lines.length > 0 && (shortCount / lines.length) > 0.8) {
            isShortOrList = true;
        }
    }

    // vi_vietlai không xử lý văn bản ngắn
    if (to === "vi_vietlai" && isShortOrList) {
        return Response.success(text);
    }

    // Chọn prompt
    var selectedPrompt = prompts[to] || prompts["vi"];

    // Kiểm tra cache (chỉ cho văn bản dài)
    var cacheKey = null;
    if (!isShortOrList) {
        try {
            cacheKey = generateFingerprintCacheKey(lines);
            var cached = localStorage.getItem(cacheKey);
            if (cached) return Response.success(cached);
        } catch (e) {
            cacheKey = null;
        }
    }

    // Chia chunk
    var CHUNK_SIZE = 3000;
    var MIN_LAST_CHUNK = 800;
    var MAX_LINES_PER_CHUNK = 50;

    var textChunks = [];
    var currentChunk = "";
    var currentLineCount = 0;

    for (var i = 0; i < lines.length; i++) {
        var para = lines[i];
        if (currentChunk.length === 0 && para.length >= CHUNK_SIZE) {
            textChunks.push(para);
            continue;
        }
        if ((currentChunk.length + para.length + 1 > CHUNK_SIZE || currentLineCount >= MAX_LINES_PER_CHUNK) && currentChunk.length > 0) {
            textChunks.push(currentChunk);
            currentChunk = para;
            currentLineCount = 1;
        } else {
            currentChunk = currentChunk ? (currentChunk + "\n" + para) : para;
            currentLineCount++;
        }
    }
    if (currentChunk.length > 0) textChunks.push(currentChunk);

    // Gộp chunk cuối nếu quá ngắn
    if (textChunks.length > 1 && textChunks[textChunks.length - 1].length < MIN_LAST_CHUNK) {
        var last = textChunks.pop();
        var secondLast = textChunks.pop();
        textChunks.push(secondLast + "\n" + last);
    }

    // Dịch từng chunk
    var finalParts = [];
    for (var k = 0; k < textChunks.length; k++) {
        var chunkResult = translateChunkWithRetry(textChunks[k], selectedPrompt, rotatedKeys);
        if (chunkResult.status === "success") {
            finalParts.push(chunkResult.data);
        } else {
            var errStr = "<<<<<--- LỖI DỊCH --->>>>>\n";
            if (chunkResult.details) errStr += chunkResult.details.join("\n");
            errStr += "\n<<<<<--- KẾT THÚC BÁO CÁO LỖI --->>>>>";
            return Response.error(errStr);
        }
    }

    var finalContent = (DEEPSEEK_MODEL + " . " + finalParts.join("\n\n")).trim();

    // Lưu cache
    if (cacheKey && finalContent) {
        manageCacheAndSave(cacheKey, finalContent);
    }

    return Response.success(finalContent);
}
