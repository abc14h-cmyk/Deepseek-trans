var languages = [
    { "id": "vi", "name": "Tiếng Việt" },
    { "id": "vi_hv", "name": "Hán Việt" },
    { "id": "en", "name": "English" },
    { "id": "zh", "name": "Tiếng Trung" },
    { "id": "ja", "name": "Tiếng Nhật" },
    { "id": "ko", "name": "Tiếng Hàn" }
];
